﻿namespace ProyectoDINT {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.BtTicketDelete = new System.Windows.Forms.DataGridViewImageColumn();
            this.btTicketAdd = new System.Windows.Forms.DataGridViewImageColumn();
            this.btTicketRemove = new System.Windows.Forms.DataGridViewImageColumn();
            this.lbTicketCant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbTicketNombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbTicketPrecio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70.4676F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.5324F));
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1219, 666);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(853, 660);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.dataGridView1, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(862, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 135F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(354, 660);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BtTicketDelete,
            this.btTicketAdd,
            this.btTicketRemove,
            this.lbTicketCant,
            this.lbTicketNombre,
            this.lbTicketPrecio});
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 40;
            this.dataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.Size = new System.Drawing.Size(348, 519);
            this.dataGridView1.TabIndex = 1;
            // 
            // BtTicketDelete
            // 
            this.BtTicketDelete.HeaderText = "Eliminar";
            this.BtTicketDelete.Name = "BtTicketDelete";
            this.BtTicketDelete.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.BtTicketDelete.Width = 40;
            // 
            // btTicketAdd
            // 
            this.btTicketAdd.HeaderText = "Añadir";
            this.btTicketAdd.Name = "btTicketAdd";
            this.btTicketAdd.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.btTicketAdd.Width = 40;
            // 
            // btTicketRemove
            // 
            this.btTicketRemove.HeaderText = "Restar";
            this.btTicketRemove.Name = "btTicketRemove";
            this.btTicketRemove.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.btTicketRemove.Width = 40;
            // 
            // lbTicketCant
            // 
            this.lbTicketCant.HeaderText = "Cant.";
            this.lbTicketCant.Name = "lbTicketCant";
            this.lbTicketCant.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.lbTicketCant.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.lbTicketCant.Width = 40;
            // 
            // lbTicketNombre
            // 
            this.lbTicketNombre.HeaderText = "Nombre";
            this.lbTicketNombre.Name = "lbTicketNombre";
            this.lbTicketNombre.Width = 110;
            // 
            // lbTicketPrecio
            // 
            this.lbTicketPrecio.HeaderText = "Precio";
            this.lbTicketPrecio.Name = "lbTicketPrecio";
            this.lbTicketPrecio.Width = 40;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1217, 662);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Mesa";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewImageColumn BtTicketDelete;
        private System.Windows.Forms.DataGridViewImageColumn btTicketAdd;
        private System.Windows.Forms.DataGridViewImageColumn btTicketRemove;
        private System.Windows.Forms.DataGridViewTextBoxColumn lbTicketCant;
        private System.Windows.Forms.DataGridViewTextBoxColumn lbTicketNombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn lbTicketPrecio;
    }
}